#!/usr/bin/env python3
def api_status():
    print("✅ ecoapi.py attivo — API placeholder")
api_status()
