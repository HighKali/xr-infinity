#!/usr/bin/env python3
import time, os

while True:
    os.system("python3 scripts/eco_miner_ui_live.py")
    time.sleep(30)
