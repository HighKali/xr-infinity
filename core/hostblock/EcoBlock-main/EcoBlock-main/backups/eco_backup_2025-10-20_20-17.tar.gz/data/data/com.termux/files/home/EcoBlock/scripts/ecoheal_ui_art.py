#!/usr/bin/env python3
def art_ui():
    print("✅ ecoheal_ui_art.py eseguito — UI artistica attiva")
art_ui()
