#!/bin/bash
echo "🚀 Deploy su Vercel (placeholder)"
# Inserisci qui il tuo comando vercel deploy
echo "✅ Deploy completato"
