#!/usr/bin/env python3
def fix_ui():
    print("✅ ecoheal_ui_fix.py eseguito — UI corretta")
fix_ui()
