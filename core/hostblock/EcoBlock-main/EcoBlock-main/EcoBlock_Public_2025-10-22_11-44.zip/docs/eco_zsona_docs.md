# 📘 Documentazione EcoBlock

## Introduzione
EcoBlock è un ecosistema blockchain modulare, etico e visivo, progettato per la collaborazione globale.

## Moduli principali
- : generazione chiavi, firma, verifica
- : minaggio reale con reward
- : validazione chain e transazioni
- : propagazione chain
- : ricezione chain
- : visualizzazione blocchi
- : statistiche reward e blocchi
- : dashboard con grafici live
- : pannello admin

## Installazione
Vedi 

## API
- : bilancio
- : salute sistema
- : blocchi
- : reward e blocchi
