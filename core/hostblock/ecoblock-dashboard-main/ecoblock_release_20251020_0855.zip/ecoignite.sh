#!/bin/bash
echo "🔥 Infusione artistica nei moduli..."
echo "EcoBlock = Etica + Arte + Automazione" > ~/ecoblock-dashboard/manifesto.txt
echo "✅ Identità infusa"
