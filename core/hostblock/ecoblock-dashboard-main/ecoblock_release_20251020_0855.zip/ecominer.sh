#!/bin/bash
echo "⛏️ Avvio mining pool XMRig..."
# Placeholder: inserisci qui il tuo comando xmrig o cryptonote
echo "✅ Mining pool avviato"
