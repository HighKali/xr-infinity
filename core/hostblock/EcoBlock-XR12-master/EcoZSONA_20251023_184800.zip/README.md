# ⚡ EcoBlock Lightning Bridge

**Versione:** 20251023_154621  
**Collaboratori:** 🪪 2  
**Stato:** LIVE

## CHANGES:
- Pulizia moduli inutilizzati
- Interfaccia pannello aggiornata
- QR, firma, tunnel, backup, sync
**Versione:** 20251023_182731
**Collaboratori:** 🪪 1
**Stato:** LIVE
**Versione:** 20251023_183538
**Collaboratori:** 🪪 2
**Stato:** LIVE
**Versione:** 20251023_183545
**Collaboratori:** 🪪 3
**Stato:** LIVE
**Versione:** 20251023_184127
**Collaboratori:** 🪪 4
**Stato:** PUBBLICATO
