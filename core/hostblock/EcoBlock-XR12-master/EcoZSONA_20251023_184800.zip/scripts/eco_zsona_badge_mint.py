print("🪪 Mint NFT badge su ZSONA chain...")
print("✅ Badge: EcoBlock Founder")
