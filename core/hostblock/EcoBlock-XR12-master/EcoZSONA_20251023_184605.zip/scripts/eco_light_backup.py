# scripts/eco_light_backup.py

import zipfile, os, datetime

# 🔐 Timestamp
stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
zipname = f"EcoZSONA_{stamp}.zip"

# 📦 Crea ZIP
with zipfile.ZipFile(zipname, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for folder in ['scripts', 'assets']:
        for root, _, files in os.walk(folder):
            for file in files:
                if any(x in file for x in ['.zip', '.DS_Store']) or '__pycache__' in root:
                    continue
                path = os.path.join(root, file)
                zipf.write(path)

    # 📄 File singoli
    for file in ['rackchain.html', 'README.md']:
        if os.path.exists(file):
            zipf.write(file)

# 🧠 Log automatico
with open("eco_log.py", "a") as log:
    log.write(f"# ✅ Backup creato: {zipname}\n")

print(f"📦 Backup completato: {zipname}")
