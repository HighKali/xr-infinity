print("🌍 Registrazione nodo globale...")
print("🪪 Firma: Zapdos")
print("🔗 QR: https://zsona.fuse.zotiav.com")
